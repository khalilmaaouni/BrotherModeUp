# Booklet

The official BrotherMode booklet remains the long-form visual explanation of the product.

It ships in this folder:

```text
brothermode-solo-builder-booklet.html
```

Open it in any browser. In the repository the same file lives at `docs/book/brothermode-solo-builder-booklet.html`.

Use the booklet for:

- product framing;
- visual explanation;
- the problem BrotherMode is designed to solve;
- deeper conceptual understanding.

Do not use the booklet as the first-run developer guide.

For engineering onboarding, start with:

1. [`../../README.md`](../../README.md)
2. [`../tutorials/getting-started.md`](../tutorials/getting-started.md)
3. [`../reference/workflow-map.md`](../reference/workflow-map.md)
4. [`../reference/verification.md`](../reference/verification.md)
